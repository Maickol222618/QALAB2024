public class Toyota extends Auto{

    Toyota(String sPlaca){
        //Inicializando
        super(sPlaca);
        super.setdVelocidadMaxima(200);
    }
}

public class Nissan extends Auto{

    public Nissan(){

    }
}
